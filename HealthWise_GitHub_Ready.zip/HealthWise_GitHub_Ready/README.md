# HealthWise Smart Premium Dashboard

Streamlit deployment for the MAIB HealthWise machine-learning assignment.

## GitHub repository structure

Upload these files exactly at the repository root:

- `app.py`
- `healthwise.csv`
- `requirements.txt`
- `runtime.txt`
- `.streamlit/config.toml`

`healthwise_model.joblib` is optional because the app can train the two-stage engine directly from `healthwise.csv`. This avoids model-version deployment failures.

## Deploy on Streamlit Community Cloud

1. Create a new GitHub repository (for example `healthwise-dashboard`).
2. Upload the files/folders in this package. Do not name the repository `healthwise.csv`.
3. In Streamlit Community Cloud choose **Create app**.
4. Select your GitHub repository and branch.
5. Set **Main file path** to `app.py`.
6. Deploy.

## Local run

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Dashboard features

- Live customer risk classification
- Tier-specific annual premium regression
- Premium sensitivity scenarios
- Portfolio visualizations
- Assignment model-performance summary
- Unseen-customer CSV upload and downloadable predictions
